//Deepthi_Mudadla_dmudadla3016@conestogac.on.ca
const Order = require("./Order");

//Welcoming categories, item and extra options
const OrderState = Object.freeze({
  WELCOMING: Symbol("welcoming"),
  ITEM: Symbol("item"),
  CATEGORY: Symbol("category"),
  EXTRAS: Symbol("extras"),
});

module.exports = class LockDownEssentials extends Order {
  constructor(sNumber, sUrl) {
    super(sNumber, sUrl);
    this.stateCur = OrderState.WELCOMING;
    this.sCategory = "";
    this.sItem = "";
    this.sExtra = "";
  }
  handleInput(sInput) {
    let aReturn = [];
    switch (this.stateCur) {
      case OrderState.WELCOMING:
        this.stateCur = OrderState.CATEGORY;

        if (sInput.toLowerCase() == "kitchen") {
          this.sCategory = "kitchen";
          aReturn.push(
            `Select one of the item:
            
            1. Household cleaner
            2. Dustbin

          `
          );
          break;
          //Outdoor options
        } else if (sInput.toLowerCase() == "outdoor") {
          this.sCategory = "outdoor";
          aReturn.push(
            `Select one of the item:
                
                1. Broom
                2. Snow shovel
                3. Garbage and Recycling container
                
                `
          );
          break;
          //Lighting options
        } else if (sInput.toLowerCase() == "lighting") {
          this.sCategory = "lighting";
          aReturn.push(
            `Select one of the item:
                    
                1. Light bulb
                    
                    `
          );
          break;
        } else if (sInput.toLowerCase() == "others") {
          this.sCategory = "others";
          aReturn.push(
            `Select one of the item:
                        
                1. Furnace filter
                2. Door screen
                        
                        `
          );
          break;
          //pdf of sign attached with the payment details
        } else {
          this.stateCur = OrderState.WELCOMING;
          aReturn.push("Welcome to Deepthi's Brampton Home Hardware- Curbside!");
          aReturn.push(`For a list of what we sell, tap on following:`);
          aReturn.push(`${this.sUrl}/payment/${this.sNumber}/`);
          aReturn.push(
            `Please type one of the following categories for a list of available items:

                1. KITCHEN
                2. OUTDOOR
                3. LIGHTING
                4. OTHERS
            `
          );
          break;
        }
        //some extra options to buy along with the main items
      case OrderState.CATEGORY:
        this.stateCur = OrderState.EXTRAS;
        if (sInput.toLowerCase() != "no") {
          this.sItem = sInput;
        }
        aReturn.push(
          `Would you also like to buy:
  
              1. Simonize car cloths
              2. Head lamps
              3. Ear buds
              4. De-scaler 
          `
        );
        break;
      case OrderState.EXTRAS:
        if (sInput.toLowerCase() != "no") {
          this.sExtras = sInput;
        }
        //Final note 
        aReturn.push("Thank-you for your order of");
        this.nTotal = 0;

        switch (this.sCategory.toLowerCase()) {
          case "kitchen":
            if (this.sItem.toLowerCase() == "household cleaner") {
              aReturn.push("Household cleaner");
              this.nTotal += 5.99;
            } else if (this.sItem.toLowerCase() == "dustbin") {
              aReturn.push("Dustbin");
              this.nTotal += 2.99;
            }
            break;
          case "outdoor":
            if (this.sItem.toLowerCase() == "broom") {
              aReturn.push("Broom");
              this.nTotal += 5.99;
            } else if (this.sItem.toLowerCase() == "snow shovel") {
              aReturn.push("Snow shovel");
              this.nTotal += 2.99;
            } else if (
              this.sItem.toLowerCase() == "garbage & recycling container"
            ) {
              aReturn.push("Garbage & Recycling container");
              this.nTotal += 2.99;
            }
            break;
          case "lighting":
            if (this.sItem.toLowerCase() == "light bulb") {
              aReturn.push("light bulb");
              this.nTotal += 5.99;
            }
            break;
          case "others":
            if (this.sItem.toLowerCase() == "furnace filter") {
              aReturn.push("Furnace filter");
              this.nTotal += 5.99;
            } else if (this.sItem.toLowerCase() == "door screen") {
              aReturn.push("Door screen");
              this.nTotal += 2.99;
            }
            break;
        }

        if (this.sExtras) {
          aReturn.push(this.sExtras);
          this.nTotal += 2.99;
        }
        aReturn.push(`Your total comes to be ${this.nTotal}`);
        aReturn.push(
          `We will text you from 519-222-2222 when your order is ready or if we have questions.`
        );
        this.isDone(true);
        break;
    }
    return aReturn;
  }
  renderForm() {
    // your client id should be kept private
    return `
      <html>
    <head>
        <meta content="text/html; charset=UTF-8" http-equiv="content-type" />
        <style type="text/css">
            ol {
                margin: 0;
                padding: 0;
            }
            table td,
            table th {
                padding: 0;
            }
            .c8 {
                border-right-style: solid;
                padding: 5pt 5pt 5pt 5pt;
                border-bottom-color: #000000;
                border-top-width: 1pt;
                border-right-width: 1pt;
                border-left-color: #000000;
                vertical-align: top;
                border-right-color: #000000;
                border-left-width: 1pt;
                border-top-style: solid;
                border-left-style: solid;
                border-bottom-width: 1pt;
                width: 225.7pt;
                border-top-color: #000000;
                border-bottom-style: solid;
            }
            .c20 {
                -webkit-text-decoration-skip: none;
                color: #000000;
                font-weight: 700;
                text-decoration: underline;
                vertical-align: baseline;
                text-decoration-skip-ink: none;
                font-size: 9pt;
                font-family: "Arial";
                font-style: normal;
            }
            .c10 {
                color: #980000;
                font-weight: 700;
                text-decoration: none;
                vertical-align: baseline;
                font-size: 11pt;
                font-family: "Arial";
                font-style: normal;
            }
            .c9 {
                color: #000000;
                font-weight: 700;
                text-decoration: none;
                vertical-align: baseline;
                font-size: 10pt;
                font-family: "Arial";
                font-style: normal;
            }
            .c2 {
                color: #000000;
                font-weight: 700;
                text-decoration: none;
                vertical-align: baseline;
                font-size: 8pt;
                font-family: "Arial";
                font-style: normal;
            }
            .c7 {
                color: #351c75;
                font-weight: 700;
                text-decoration: none;
                vertical-align: baseline;
                font-size: 11pt;
                font-family: "Arial";
                font-style: normal;
            }
            .c29 {
                padding-top: 12pt;
                padding-bottom: 12pt;
                line-height: 1.15;
                orphans: 2;
                widows: 2;
                text-align: center;
            }
            .c5 {
                padding-top: 0pt;
                padding-bottom: 0pt;
                line-height: 1.15;
                orphans: 2;
                widows: 2;
                text-align: center;
            }
            .c16 {
                padding-top: 0pt;
                padding-bottom: 0pt;
                line-height: 1.15;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            .c4 {
                padding-top: 0pt;
                padding-bottom: 12pt;
                line-height: 1.15;
                orphans: 2;
                widows: 2;
                text-align: center;
            }
            .c0 {
                padding-top: 0pt;
                padding-bottom: 0pt;
                line-height: 1;
                text-align: left;
                height: 11pt;
            }
            .c14 {
                color: #0000ff;
                text-decoration: none;
                vertical-align: baseline;
                font-family: "Arial";
                font-style: normal;
            }
            .c11 {
                color: #000000;
                text-decoration: none;
                vertical-align: baseline;
                font-family: "Arial";
                font-style: normal;
            }
            .c13 {
                padding-top: 12pt;
                padding-bottom: 12pt;
                line-height: 1;
                text-align: left;
            }
            .c25 {
                border-spacing: 0;
                border-collapse: collapse;
                margin-right: auto;
            }
            .c26 {
                -webkit-text-decoration-skip: none;
                color: #980000;
                text-decoration: underline;
                text-decoration-skip-ink: none;
            }
            .c15 {
                padding-top: 0pt;
                padding-bottom: 0pt;
                line-height: 1;
                text-align: left;
            }
            .c1 {
                font-size: 3pt;
                font-family: "Times New Roman";
                font-weight: 700;
            }
            .c27 {
                background-color: #ffffff;
                max-width: 451.4pt;
                padding: 72pt 72pt 72pt 72pt;
            }
            .c3 {
                font-size: 8pt;
                font-weight: 700;
            }
            .c23 {
                font-size: 9pt;
                font-weight: 700;
            }
            .c6 {
                font-size: 7pt;
                font-weight: 700;
            }
            .c28 {
                font-size: 10pt;
                font-weight: 700;
            }
            .c12 {
                font-weight: 400;
                font-size: 11pt;
            }
            .c22 {
                font-weight: 400;
                font-size: 6pt;
            }
            .c17 {
                margin-left: 18pt;
                text-indent: -18pt;
            }
            .c24 {
                font-weight: 400;
                font-size: 7pt;
            }
            .c18 {
                height: 0pt;
            }
            .c19 {
                height: 40.5pt;
            }
            .c21 {
                height: 11pt;
            }
            .title {
                padding-top: 0pt;
                color: #000000;
                font-size: 26pt;
                padding-bottom: 3pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            .subtitle {
                padding-top: 0pt;
                color: #666666;
                font-size: 15pt;
                padding-bottom: 16pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            li {
                color: #000000;
                font-size: 11pt;
                font-family: "Arial";
            }
            p {
                margin: 0;
                color: #000000;
                font-size: 11pt;
                font-family: "Arial";
            }
            h1 {
                padding-top: 20pt;
                color: #000000;
                font-size: 20pt;
                padding-bottom: 6pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            h2 {
                padding-top: 18pt;
                color: #000000;
                font-size: 16pt;
                padding-bottom: 6pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            h3 {
                padding-top: 16pt;
                color: #434343;
                font-size: 14pt;
                padding-bottom: 4pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            h4 {
                padding-top: 14pt;
                color: #666666;
                font-size: 12pt;
                padding-bottom: 4pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            h5 {
                padding-top: 12pt;
                color: #666666;
                font-size: 11pt;
                padding-bottom: 4pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
            h6 {
                padding-top: 12pt;
                color: #666666;
                font-size: 11pt;
                padding-bottom: 4pt;
                font-family: "Arial";
                line-height: 1.15;
                page-break-after: avoid;
                font-style: italic;
                orphans: 2;
                widows: 2;
                text-align: left;
            }
        </style>
    </head>
    <body class="c27">
        <p class="c5"><span class="c10">Brampton Home Hardware</span></p>
        <p class="c5"><span class="c7">Curbside Pick Up Options</span></p>
        <p class="c5 c21"><span class="c7"></span></p>
        <p class="c4"><span class="c20">Order Online</span></p>
        <p class="c5"><span class="c11 c6">Find something you need for your home</span></p>
        <p class="c5"><span class="c11 c6">and choose Curbside Pickup when you add</span></p>
        <p class="c5"><span class="c11 c6">to your cart and it will be ready in just just</span></p>
        <p class="c5"><span class="c11 c6">2 hours!</span></p>
        <p class="c5"><span class="c11 c6">&nbsp;</span></p>
        <p class="c4"><span class="c20">Check Your Email</span></p>
        <p class="c5"><span class="c6">Once we let you know your order is ready via our Email id </span><span class="c6 c14">bramptonhomehardware@gmail.com</span></p>
        <p class="c5"><span class="c11 c6">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;head to our store and have your</span></p>
        <p class="c5"><span class="c11 c6">email confirmation ready.</span></p>
        <p class="c5"><span class="c11 c6">&nbsp;</span></p>
        <p class="c4"><span class="c20">Pick Up from Your Car</span></p>
        <p class="c5"><span class="c11 c6">When you arrive, call the number in your</span></p>
        <p class="c5"><span class="c6 c11">email. Show your receipt from your closed window and pop open the trunk!</span></p>
        <p class="c29"><span class="c23 c26">List of Items</span></p>
        <a id="t.b5583a262f4eef83937036f24d3f8a25a934d83c"></a><a id="t.0"></a>
        <table class="c25">
            <tbody>
                <tr class="c18">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c23">Brooms and dustbins</span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c0"><span class="c11 c12"></span></p>
                        <p class="c15"><span class="c11 c12">5.99$</span></p>
                    </td>
                </tr>
                <tr class="c18">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c28">Snow Shovels</span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c15"><span class="c11 c12">2.99$</span></p>
                    </td>
                </tr>
                <tr class="c18">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c9">Garbage and recycling containers combo</span></p>
                        <p class="c0"><span class="c11 c24"></span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c15"><span class="c11 c12">8.99$</span></p>
                    </td>
                </tr>
                <tr class="c18">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c9">Light Bulbs (Pack of 6)</span></p>
                        <p class="c0"><span class="c11 c24"></span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c15"><span class="c11 c12">9.99$</span></p>
                    </td>
                </tr>
                <tr class="c18">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c9">Household cleaners Combo set</span></p>
                        <p class="c13 c17"><span class="c3">&middot;</span><span class="c1">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="c2">Pine-Sol Lavender Cleaner, 4.25-L</span></p>
                        <p class="c13 c17"><span class="c3">&middot;</span><span class="c1">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="c2">Windex Original, 765 ml</span></p>
                        <p class="c13 c17"><span class="c3">&middot;</span><span class="c1">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="c2">Lysol All-Purpose Cleaner, 4.36-L</span></p>
                        <p class="c13 c17"><span class="c3">&middot;</span><span class="c1">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="c2">Mr. Clean, 2.4-L</span></p>
                        <p class="c13 c17"><span class="c3">&middot;</span><span class="c1">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="c3">Liquid-Plumr Pro Strength Drainer, 500 ml</span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c15"><span class="c11 c12">28.99$</span></p>
                    </td>
                </tr>
                <tr class="c19">
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c13"><span class="c9">Furnace filters and screen when cat climbs on your screen door!</span></p>
                        <p class="c13 c21"><span class="c9"></span></p>
                    </td>
                    <td class="c8" colspan="1" rowspan="1">
                        <p class="c15"><span class="c11 c12">11.89$</span></p>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="c16"><span class="c11 c12">&nbsp;</span></p>
        <p class="c16 c21"><span class="c11 c12"></span></p>
        <p class="c16 c21"><span class="c11 c12"></span></p>
    </body>
</html>
`;
  }
};
//End of the curbside payment and other options